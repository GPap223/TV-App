import java.util.Scanner;

public class Askshsh2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        TV TV = new TV();
        System.out.println("Do you want to turn on the TV? (press: yes/no):");
        String choice = scanner.nextLine();
       
        if (choice.equalsIgnoreCase("yes"))
        {
            TV.turnOn();
            System.out.println("-- SAMSUNG --");
        }
        else
        {
            System.out.println("The TV is OFF");
            
        }
        while (TV.isOn())
        {
            System.out.println("The TV now shows the channel number: " + TV.getChannel() + " and the volume is: " + TV.getVolume());
            System.out.println("Do you want to fix the volume? (Please type yes/no):");
            String choice1=scanner.nextLine();
            if (choice1.equalsIgnoreCase("yes"))
            {
                System.out.println("If you want to set the volume up press the '+' button or if you want to set it down press the '-' button.");
                System.out.print("Press one of the two buttons: ");
                String choice11 = scanner.nextLine();
               
                TV.controlVolume(choice11);
                System.out.println("The volume now is: " + TV.getVolume());
            }
           
            System.out.println("Do you want to change the channel? (Please type yes/no):");
            String choice2 = scanner.nextLine();
            if (choice2.equalsIgnoreCase("yes"))
            {
                System.out.println("If you want to increase the channel press the '+' button or if you want to decrease the channel press the '-' button.");
                System.out.print("Press one of the two buttons or set the channel you want: ");
                String choice22 = scanner.nextLine();
               
                TV.controlChannel(choice22);
                System.out.println("The TV now shows the channel number: " + TV.getChannel());
            }
            System.out.println("Do you want to turn off the TV? (press: yes/no):");
            String choice3 = scanner.nextLine();
            if (choice3.equalsIgnoreCase("yes"))
            {
                TV.turnOff();
                System.out.println("The TV is now OFF.");
            }
        }

        scanner.close();
    }
}