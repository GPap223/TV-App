public class TV
{
    private boolean isOn;
    private int channel;
    private int volume;

    public TV()
    {
        this.isOn=false;
        this.channel=1;
        this.volume=0;
    }

    public int getChannel()
    {
        return channel;
    }

    public int getVolume()
    {
        return volume;
    }

    public boolean isOn()
    {
        return isOn;
    }

    public void turnOn()
    {
        this.isOn=true;
    }

    public void turnOff()
    {
        this.isOn=false;
    }
   public void controlVolume(String epilogh)
   {
        if (epilogh.equals("+")) 
        {
           volume++;
          if (volume>50) 
          {
            volume = 0;       
          }
       }    
      else if (epilogh.equals("-")) 
      {
          volume--;
          if (volume<0) 
          {
            volume = 50; 
          }
      }
   }
    
    public void controlChannel(String epilogh)
    {
        if (epilogh.equals("+")) 
        {
            channel++;
            if (channel > 100)
             {
                channel = 1; 
            }

        } 
        else if (epilogh.equals("-")) 
        {
            channel--;
            if (channel < 1) 
            {
                channel = 100;
            }
        }
        else if(!epilogh.equals("+") && (!epilogh.equals("-")))
        {
         this.channel=Integer.parseInt(epilogh);

        }
    }
}
   
        
